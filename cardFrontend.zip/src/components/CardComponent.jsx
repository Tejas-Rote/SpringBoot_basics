import { useState } from "react";
import "./CardComponent.css";
import chip from "../assets/chip.png";
import approx from "../assets/aprox.png";
import axios from "axios";

const CardComponent = (props) => {
  const { userId } = props;
  const [cardNumber, setCardNumber] = useState("");
  const [cardHolder, setCardHolder] = useState("");
  const [validThru, setValidThru] = useState("");
  const [cvv, setCvv] = useState("");
  const [pin, setPin] = useState("");
  const [cardType, setCardType] = useState("");

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "card-number":
        setCardNumber(value);
        break;
      case "name-text":
        setCardHolder(value);
        break;
      case "valid-thru-text":
        setValidThru(value);
        break;
      case "cvv-text":
        setCvv(value);
        break;
      case "pin-text":
        setPin(value);
        break;
      case "card-type-text":
        setCardType(value);
        break;
      default:
        break;
    }
  };

  const formatCardNumber = (input) => {
    // Format card number as per input
    const formattedInput = input.replaceAll(" ", "");
    if (formattedInput.length > 0) {
      let formattedNumber = "";
      for (let i = 0; i < formattedInput.length; i++) {
        if (i % 4 === 0 && i !== 0) formattedNumber += " ";
        formattedNumber += formattedInput[i];
      }
      return formattedNumber;
    }
    return "";
  };

  const formatExpiration = (input) => {
    // Format expiration date as per input
    const formattedInput = input.replace("/", "");
    if (formattedInput.length > 0) {
      let formattedExpiration = formattedInput.replace(
        /^(\d{2})(\d{0,2})/,
        "$1/$2"
      );
      return formattedExpiration;
    }
    return "";
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    addCreditCard();
  };

  const addCreditCard = async () => {
    const requestUrl = "http://localhost:8080/cards";

    const data = {
      userId: userId,
      cardNumber: cardNumber,
      cardHolder: cardHolder,
      validThru: validThru,
      cvv: cvv,
      pin: pin,
      cardType: cardType,
    };
    // console.log(data);

    try {
      const response = await axios.post(requestUrl, data, {
        headers: {
          "Content-Type": "application/json",
          //   "Authorization":"Bearer <jwtToken>"
          // add authorization header here and pass jwt token
        },
      });
      console.log(response);
      alert("Credit Card Added!");
    } catch (error) {
      console.error("Error adding credit card:", error);
      alert("Error adding credit card!");
    }
  };

  return (
    <div className="card-wrapper">
      <main className="container">
        <section className="ui">
          <div className="container-left">
            <form id="credit-card" onSubmit={handleSubmit}>
              <div className="number-container">
                <label>Card Number</label>
                <input
                  type="text"
                  name="card-number"
                  id="card-number"
                  maxLength="19"
                  placeholder="1234 5678 9101 1121"
                  required
                  value={formatCardNumber(cardNumber)}
                  onChange={handleInputChange}
                />
              </div>
              <div className="name-container">
                <label>Holder</label>
                <input
                  type="text"
                  name="name-text"
                  id="name-text"
                  maxLength="30"
                  placeholder="NOAH JACOB"
                  required
                  value={cardHolder.toUpperCase()}
                  onChange={handleInputChange}
                />
              </div>
              <div className="infos-container">
                <div className="expiration-container">
                  <label>Valid-thru</label>
                  <input
                    type="text"
                    name="valid-thru-text"
                    id="valid-thru-text"
                    maxLength="5"
                    placeholder="02/40"
                    required
                    value={formatExpiration(validThru)}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="cvv-container">
                  <label>CVV</label>
                  <input
                    type="text"
                    name="cvv-text"
                    id="cvv-text"
                    maxLength="4"
                    placeholder="1234"
                    required
                    value={cvv}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              <div className="infos-container">
                <div className="pin-container">
                  <label>PIN</label>
                  <input
                    type="text"
                    name="pin-text"
                    id="pin-text"
                    maxLength="4"
                    placeholder="****"
                    required
                    value={pin}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="card-type-container">
                  <label>Card Type</label>
                  <input
                    type="text"
                    name="card-type-text"
                    id="card-type-text"
                    placeholder="VISA, etc."
                    value={cardType}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              <input type="submit" value="ADD" id="add" />
            </form>
          </div>
          <div className="container-right">
            <div className="card">
              <div className="intern">
                <img
                  className="approximation"
                  src={approx}
                  alt="aproximation"
                />
                <div className="card-number">
                  <div className="number-vl">
                    {formatCardNumber(cardNumber)}
                  </div>
                </div>
                <div className="card-holder">
                  <label>Holder</label>
                  <div className="name-vl">{cardHolder.toUpperCase()}</div>
                </div>
                <div className="card-infos">
                  <div className="exp">
                    <label>valid-thru</label>
                    <div className="expiration-vl">
                      {formatExpiration(validThru)}
                    </div>
                  </div>
                  <div className="cvv">
                    <label>CVV</label>
                    <div className="cvv-vl">{cvv}</div>
                  </div>
                </div>

                {/* <div className="card-infos">
                  <div className="pin">
                    <label>PIN</label>
                    <div className="pin-vl">{pin}</div>
                  </div>
                  <div className="card-type">
                    <label>Card Type</label>
                    <div className="card-type-vl">{cardType}</div>
                  </div>
                </div> */}

                <img className="chip" src={chip} alt="chip" />
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default CardComponent;
