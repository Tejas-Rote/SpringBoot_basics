import "./App.css";
import CardComponent from "./components/CardComponent";

function App() {
  return (
    <div className="app">
      <div className="wrapper">
        {/* // pass userId for logged in person as props */}
        <CardComponent userId={4} />
      </div>
    </div>
  );
}

export default App;
